# west-friction

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/leo-zuire/pen/019e5fa3-0b09-7746-a4bf-68e6c7aed1f5](https://codepen.io/editor/leo-zuire/pen/019e5fa3-0b09-7746-a4bf-68e6c7aed1f5).

